#!/usr/bin/python
# -*- coding: utf-8 -*-


import xbmc

xbmc.executebuiltin('Addon.OpenSettings(plugin.video.lttateam)')